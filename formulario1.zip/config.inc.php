<?php 
$wsconfig['username'] = 'admin'; 
$wsconfig['accesskey'] = 'TM8Q9DDh8q9cFSo'; 
$wsconfig['redirect'] = ''; 
$wsconfig['targetmodule'] = 'Contacts |##| Accounts |##| Potentials |##| HelpDesk'; 
$wsconfig['url'] = 'https://develop.datacrm.la/datacrm/datacrm63192/'; 
?>